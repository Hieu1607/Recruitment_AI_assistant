from __future__ import annotations

from pathlib import Path
from typing import Iterable
import math

from PIL import Image, ImageDraw, ImageFont


ROOT = Path(__file__).resolve().parent
OUT_DIR = ROOT / "Hinhve"
OUT_DIR.mkdir(parents=True, exist_ok=True)

W, H = 1800, 1200

BG = "#F4F7FB"
NAVY = "#1E3A5A"
BLUE = "#3668E8"
SOFT_BLUE = "#DBE7FF"
GREEN = "#DDF3E7"
GREEN_D = "#2D8A57"
ORANGE = "#FDECCB"
ORANGE_D = "#C47B19"
PINK = "#F8DDE8"
PINK_D = "#C84C74"
PURPLE = "#E8DEFF"
PURPLE_D = "#6E47C7"
GRAY = "#5B6470"
LINE = "#BCC8D8"
WHITE = "#FFFFFF"
SHADOW = "#E3EAF4"


def load_font(candidates: Iterable[str], size: int) -> ImageFont.FreeTypeFont | ImageFont.ImageFont:
    for candidate in candidates:
        try:
            return ImageFont.truetype(candidate, size)
        except OSError:
            continue
    return ImageFont.load_default()


FONT_CANDIDATES = [
    r"C:\Windows\Fonts\segoeui.ttf",
    r"C:\Windows\Fonts\arial.ttf",
]
FONT_BOLD_CANDIDATES = [
    r"C:\Windows\Fonts\segoeuib.ttf",
    r"C:\Windows\Fonts\arialbd.ttf",
]

FONT_TITLE = load_font(FONT_BOLD_CANDIDATES, 46)
FONT_SUBTITLE = load_font(FONT_CANDIDATES, 24)
FONT_TEXT = load_font(FONT_CANDIDATES, 18)
FONT_BOX = load_font(FONT_BOLD_CANDIDATES, 22)
FONT_ENTITY_TITLE = load_font(FONT_BOLD_CANDIDATES, 18)
FONT_ENTITY_FIELD = load_font(FONT_CANDIDATES, 17)
FONT_STEP_NUMBER = load_font(FONT_CANDIDATES, 20)


def new_canvas() -> tuple[Image.Image, ImageDraw.ImageDraw]:
    image = Image.new("RGB", (W, H), BG)
    return image, ImageDraw.Draw(image)


def draw_header(draw: ImageDraw.ImageDraw, title: str, subtitle: str) -> None:
    draw.text((72, 42), title, font=FONT_TITLE, fill=NAVY)
    draw.text((74, 106), subtitle, font=FONT_SUBTITLE, fill=GRAY)
    draw.line((72, 150, W - 72, 150), fill=LINE, width=3)


def rounded_box(
    draw: ImageDraw.ImageDraw,
    xy: tuple[int, int, int, int],
    fill: str,
    outline: str = LINE,
    radius: int = 24,
    width: int = 2,
) -> None:
    draw.rounded_rectangle(xy, radius=radius, fill=fill, outline=outline, width=width)


def shadowed_box(
    draw: ImageDraw.ImageDraw,
    xy: tuple[int, int, int, int],
    fill: str = WHITE,
    outline: str = LINE,
    radius: int = 24,
) -> None:
    x1, y1, x2, y2 = xy
    rounded_box(draw, (x1 + 9, y1 + 11, x2 + 9, y2 + 11), SHADOW, outline=SHADOW, radius=radius, width=1)
    rounded_box(draw, xy, fill, outline=outline, radius=radius, width=2)


def wrap_text(draw: ImageDraw.ImageDraw, text: str, font: ImageFont.ImageFont, max_width: int) -> list[str]:
    text = text.replace("\n", " \n ")
    words = text.split()
    lines: list[str] = []
    current = ""
    for word in words:
        if word == r"\n":
            if current:
                lines.append(current)
                current = ""
            continue
        candidate = f"{current} {word}".strip()
        bbox = draw.textbbox((0, 0), candidate, font=font)
        if not current or bbox[2] <= max_width:
            current = candidate
        else:
            lines.append(current)
            current = word
    if current:
        lines.append(current)
    return lines


def draw_box_text(
    draw: ImageDraw.ImageDraw,
    box: tuple[int, int, int, int],
    text: str,
    font: ImageFont.ImageFont,
    fill: str = NAVY,
    align: str = "center",
    line_gap: int = 6,
) -> None:
    x1, y1, x2, y2 = box
    max_width = x2 - x1
    lines = wrap_text(draw, text, font, max_width)
    bbox = draw.multiline_textbbox((0, 0), "\n".join(lines), font=font, spacing=line_gap, align=align)
    text_w = bbox[2] - bbox[0]
    text_h = bbox[3] - bbox[1]
    if align == "center":
        x = x1 + (max_width - text_w) / 2
    else:
        x = x1
    y = y1 + ((y2 - y1) - text_h) / 2
    draw.multiline_text((x, y), "\n".join(lines), font=font, fill=fill, spacing=line_gap, align=align)


def draw_paragraph(
    draw: ImageDraw.ImageDraw,
    x: int,
    y: int,
    width: int,
    text: str,
    font: ImageFont.ImageFont = FONT_SUBTITLE,
    fill: str = GRAY,
    line_gap: int = 8,
) -> None:
    lines = wrap_text(draw, text, font, width)
    draw.multiline_text((x, y), "\n".join(lines), font=font, fill=fill, spacing=line_gap)


def draw_arrow(
    draw: ImageDraw.ImageDraw,
    start: tuple[int, int],
    end: tuple[int, int],
    color: str = BLUE,
    width: int = 5,
    head: int = 15,
) -> None:
    x1, y1 = start
    x2, y2 = end
    draw.line((x1, y1, x2, y2), fill=color, width=width)
    angle = math.atan2(y2 - y1, x2 - x1)
    left = (x2 - head * math.cos(angle + math.pi / 7), y2 - head * math.sin(angle + math.pi / 7))
    right = (x2 - head * math.cos(angle - math.pi / 7), y2 - head * math.sin(angle - math.pi / 7))
    draw.polygon([end, left, right], fill=color)


def draw_entity(
    draw: ImageDraw.ImageDraw,
    box: tuple[int, int, int, int],
    title: str,
    fields: list[str],
    fill: str = WHITE,
) -> None:
    shadowed_box(draw, box, fill=fill)
    x1, y1, x2, y2 = box
    header_h = 52
    draw.rounded_rectangle((x1, y1, x2, y1 + header_h), radius=24, fill=NAVY)
    draw.rectangle((x1, y1 + header_h - 24, x2, y1 + header_h), fill=NAVY)
    draw_box_text(draw, (x1 + 16, y1 + 8, x2 - 16, y1 + header_h - 6), title, FONT_ENTITY_TITLE, fill=WHITE)

    field_y = y1 + header_h + 22
    for field in fields:
        draw.text((x1 + 18, field_y), f"• {field}", font=FONT_ENTITY_FIELD, fill=NAVY)
        field_y += 38


def generate_architecture() -> None:
    image, draw = new_canvas()
    draw_header(
        draw,
        "Kiến trúc tổng thể EasyHR",
        "Luồng chính từ người dùng đến các thành phần giao diện, xử lý nghiệp vụ và lưu trữ dữ liệu",
    )

    boxes = {
        "browser": ((90, 330, 350, 500), SOFT_BLUE, "Người dùng\nTrình duyệt web"),
        "frontend": ((470, 260, 770, 430), WHITE, "Frontend\nReact + Vite"),
        "nginx": ((470, 530, 770, 700), WHITE, "Reverse proxy\nNginx / static assets"),
        "backend": ((900, 260, 1210, 430), WHITE, "Backend API\nFastAPI"),
        "worker": ((900, 530, 1210, 700), WHITE, "Xử lý nền\nCelery Worker"),
        "db": ((1370, 190, 1700, 340), GREEN, "Cơ sở dữ liệu\nPostgreSQL"),
        "redis": ((1370, 390, 1700, 540), ORANGE, "Hàng đợi / bộ nhớ đệm\nRedis"),
        "storage": ((1370, 590, 1700, 740), PURPLE, "Lưu trữ tệp\nMinIO / file storage"),
        "llm": ((930, 840, 1240, 1000), PINK, "Dịch vụ AI\nLLM Provider"),
    }

    for xy, fill, label in boxes.values():
        shadowed_box(draw, xy, fill=fill)
        draw_box_text(draw, (xy[0] + 20, xy[1] + 24, xy[2] - 20, xy[3] - 24), label, FONT_BOX)

    draw_arrow(draw, (350, 415), (470, 345), color=BLUE)
    draw_arrow(draw, (350, 415), (470, 615), color=GRAY)
    draw_arrow(draw, (770, 345), (900, 345), color=BLUE)
    draw_arrow(draw, (770, 615), (900, 615), color=GRAY)
    draw_arrow(draw, (1055, 430), (1055, 530), color=BLUE)
    draw_arrow(draw, (1210, 315), (1370, 265), color=GREEN_D)
    draw_arrow(draw, (1210, 345), (1370, 465), color=ORANGE_D)
    draw_arrow(draw, (1210, 385), (1370, 665), color=PURPLE_D)
    draw_arrow(draw, (1055, 700), (1055, 840), color=PINK_D)

    draw_paragraph(
        draw,
        380,
        760,
        430,
        "Frontend hiển thị giao diện quản lý ứng viên, mô tả công việc, kết quả chấm điểm và các bước sau sàng lọc. Backend chịu trách nhiệm xử lý dữ liệu, gọi mô hình AI và lưu trạng thái vào các thành phần lưu trữ.",
        font=FONT_TEXT,
    )

    image.save(OUT_DIR / "easyhr_kien_truc_tong_the.png")


def generate_data_model() -> None:
    image, draw = new_canvas()
    draw_header(
        draw,
        "Mô hình dữ liệu khái quát",
        "Các thực thể chính và mối liên hệ phục vụ luồng tuyển dụng của EasyHR",
    )

    entities = [
        ((90, 220, 390, 450), "Job", ["id", "title", "owner_user_id"], SOFT_BLUE),
        ((470, 220, 810, 480), "JobDescription", ["id", "job_id", "jd_text", "is_active"], WHITE),
        ((890, 220, 1230, 480), "MatchRun", ["id", "job_description_id", "score_threshold", "run_status"], ORANGE),
        ((90, 580, 390, 870), "ResumeDocument", ["id", "job_id", "upload_status", "storage_uri"], WHITE),
        ((470, 580, 810, 930), "CandidateProfile", ["id", "resume_document_id", "full_name", "skills_text", "experience_years"], GREEN),
        ((890, 580, 1230, 870), "MatchResult", ["id", "match_run_id", "candidate_profile_id", "total_score"], WHITE),
        ((1320, 200, 1710, 430), "ShortlistCollection", ["id", "name", "job_id / source_query_turn_id"], PURPLE),
        ((1320, 500, 1710, 760), "QuerySession / QueryTurn", ["id", "job_id", "user_question", "matched_candidate_ids"], WHITE),
        ((1320, 830, 1710, 1080), "Outreach / Interview", ["outreach_messages", "interview_question_sets", "candidate_profile_id"], PINK),
    ]

    for xy, title, fields, fill in entities:
        draw_entity(draw, xy, title, fields, fill=fill)

    # Horizontal arrows on dedicated channels
    draw_arrow(draw, (390, 335), (470, 335), color=BLUE)
    draw_arrow(draw, (810, 365), (890, 365), color=ORANGE_D)
    draw_arrow(draw, (390, 725), (470, 725), color=GREEN_D)
    draw_arrow(draw, (810, 725), (890, 725), color=GREEN_D)
    draw_arrow(draw, (1230, 715), (1320, 620), color=PURPLE_D)
    draw_arrow(draw, (1230, 760), (1320, 955), color=PINK_D)

    # Vertical arrows with margins so they do not cross labels.
    draw_arrow(draw, (240, 450), (240, 580), color=BLUE)
    draw_arrow(draw, (1060, 480), (1060, 580), color=ORANGE_D)

    draw_paragraph(
        draw,
        90,
        1088,
        1180,
        "Quan hệ chính: một Job có nhiều CV và mô tả công việc; mỗi CV sinh ra một hồ sơ ứng viên; kết quả chấm điểm và các bước sau sàng lọc đều bám theo hồ sơ ứng viên.",
        font=FONT_SUBTITLE,
    )

    image.save(OUT_DIR / "easyhr_mo_hinh_du_lieu.png")


def draw_step_flow(
    title: str,
    subtitle: str,
    body: str,
    steps: list[str],
    fills: list[tuple[str, str]],
    filename: str,
) -> None:
    image, draw = new_canvas()
    draw_header(draw, title, subtitle)

    box_w = 268
    box_h = 196
    gap = 48
    total_w = len(steps) * box_w + (len(steps) - 1) * gap
    start_x = (W - total_w) // 2
    y = 328

    for idx, step in enumerate(steps):
        x = start_x + idx * (box_w + gap)
        fill, badge = fills[idx]
        shadowed_box(draw, (x, y, x + box_w, y + box_h), fill=fill)
        draw.ellipse((x + 18, y + 18, x + 72, y + 72), fill=badge)
        draw_box_text(draw, (x + 18, y + 18, x + 72, y + 72), str(idx + 1), FONT_STEP_NUMBER, fill=WHITE)
        draw_box_text(draw, (x + 86, y + 30, x + box_w - 18, y + box_h - 20), step, FONT_BOX)
        if idx < len(steps) - 1:
            draw_arrow(draw, (x + box_w, y + box_h // 2), (x + box_w + gap, y + box_h // 2), color=BLUE)

    body_w = min(1500, total_w + 40)
    body_x = (W - body_w) // 2
    draw_paragraph(draw, body_x, 600, body_w, body, font=FONT_SUBTITLE)
    image.save(OUT_DIR / filename)


def generate_flows() -> None:
    draw_step_flow(
        "Luồng xử lý CV",
        "Chuỗi bước chính trong quá trình tiếp nhận, phân tích và chuẩn hóa dữ liệu ứng viên",
        "Luồng này mô tả từ lúc nhà tuyển dụng tải tệp PDF đến khi hệ thống sinh hồ sơ ứng viên có cấu trúc để phục vụ tìm kiếm và chấm điểm.",
        [
            "Tải tệp PDF",
            "Trích xuất văn bản",
            "LLM phân tích nội dung",
            "Chuẩn hóa hồ sơ ứng viên",
            "Lưu dữ liệu và cập nhật trạng thái",
        ],
        [
            (SOFT_BLUE, BLUE),
            (WHITE, NAVY),
            (PINK, PINK_D),
            (GREEN, GREEN_D),
            (ORANGE, ORANGE_D),
        ],
        "easyhr_luong_xu_ly_cv.png",
    )

    draw_step_flow(
        "Luồng chấm điểm ứng viên",
        "Chuỗi bước từ chọn mô tả công việc đến sinh kết quả đánh giá có giải thích",
        "Luồng này cho thấy cách hệ thống lấy mô tả công việc và danh sách ứng viên, gửi dữ liệu cho mô hình AI, sau đó lưu lại điểm số và phần giải thích để nhà tuyển dụng xem lại.",
        [
            "Chọn mô tả công việc",
            "Chọn tập ứng viên",
            "Thiết lập trọng số",
            "LLM đánh giá theo tiêu chí",
            "Lưu MatchResult và hiển thị kết quả",
        ],
        [
            (SOFT_BLUE, BLUE),
            (WHITE, NAVY),
            (PURPLE, PURPLE_D),
            (PINK, PINK_D),
            (GREEN, GREEN_D),
        ],
        "easyhr_luong_cham_diem.png",
    )


def generate_pending_figure(filename: str, title: str, lines: list[str]) -> None:
    image, draw = new_canvas()
    shadowed_box(draw, (170, 140, 1630, 1010), fill=WHITE)
    draw.rounded_rectangle((240, 220, 1560, 330), radius=24, fill=NAVY)
    draw_box_text(draw, (270, 238, 1530, 312), title, FONT_TITLE, fill=WHITE)
    draw_paragraph(
        draw,
        270,
        400,
        1200,
        "Bạn sẽ thay hình này bằng ảnh chụp giao diện thật sau khi hoàn thiện và chạy hệ thống.",
        font=FONT_SUBTITLE,
    )

    y = 520
    for line in lines:
        draw.ellipse((280, y + 6, 302, y + 28), fill=BLUE)
        draw_paragraph(draw, 330, y, 1150, line, font=FONT_SUBTITLE)
        y += 130

    draw.rounded_rectangle((260, 870, 1540, 950), radius=18, fill=SOFT_BLUE)
    draw_box_text(
        draw,
        (280, 888, 1520, 932),
        "Khi có ảnh thật, chỉ cần thay đúng file này để giữ nguyên bố cục LaTeX.",
        FONT_SUBTITLE,
    )

    image.save(OUT_DIR / filename)


def generate_pending_figures() -> None:
    generate_pending_figure(
        "easyhr_giao_dien_ung_vien_pending.png",
        "Ảnh chờ thay: màn hình quản lý ứng viên",
        [
            "Nên chụp màn hình danh sách ứng viên hoặc dashboard thể hiện số liệu, bảng dữ liệu và bộ lọc.",
            "Giữ thanh điều hướng và vùng nội dung chính để người xem nhận ra bố cục hệ thống.",
            "Ẩn dữ liệu nhạy cảm hoặc dùng dữ liệu mẫu rõ ràng, dễ đọc.",
        ],
    )
    generate_pending_figure(
        "easyhr_ket_qua_cham_diem_pending.png",
        "Ảnh chờ thay: màn hình kết quả chấm điểm",
        [
            "Nên chụp bảng kết quả gồm tên ứng viên, điểm tổng, trạng thái đạt ngưỡng và phần giải thích ngắn.",
            "Ưu tiên một màn hình có cả bộ lọc hoặc thông tin mô tả công việc để ngữ cảnh rõ hơn.",
            "Tránh chụp quá dài; chỉ giữ phần có giá trị minh họa trực tiếp cho đồ án.",
        ],
    )


def main() -> None:
    generate_architecture()
    generate_data_model()
    generate_flows()
    generate_pending_figures()
    print("Generated thesis figures in", OUT_DIR)


if __name__ == "__main__":
    main()
